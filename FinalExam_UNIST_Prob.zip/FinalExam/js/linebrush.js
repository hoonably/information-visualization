class lineBrush {

    constructor() {
        this.data = null;
        this.currentCountry = null;
    }

    initData(data) {
        try {

            this.data = data
            this.currentCountry = "Afghanistan"

            this.drawLineBrush()

        }
        catch (error) {
            console.error(error);
        };
    }


    drawLineBrush() {
        // Filter data
        const filteredData = this.data.filter(d => {
            return d.location == this.currentCountry
        })

        // Canvas Size
        const margin = { top: 5, right: 50, bottom: 50, left: 120 },
            width = 1400 - margin.left - margin.right,
            height = 100 - margin.top - margin.bottom;

        // Define the position of the chart 
        const svg = d3.select("#linebrush")
            .append("svg")
            .attr('width', width + margin.left + margin.right)
            .attr('height', height + margin.top + margin.bottom)
            .append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);

        // [Your Code Here]
        // Add brush event

        // Define Scales
        var xScale = d3.scaleTime().domain(d3.extent(filteredData, function (d) { return d.date })).range([0, width]);
        var yScale = d3.scaleLinear().domain([0, d3.max(filteredData, function (d) { return d.total_cases })]).range([height, 0]);

        // Draw X Axis
        svg.append("g")
            .attr("transform", "translate(0," + height + ")")
            .call(d3.axisBottom(xScale))
            .append('text')
            .attr('text-anchor', 'middle')
            .text('Date');

        // Draw lines
        svg.append("path")
            .datum(filteredData)
            .attr("fill", "none")
            // .attr("style", "outline: thin solid black;")
            .attr("stroke", "steelblue")
            .attr("stroke-width", 1.5)
            .attr("d", d3.line()
                .x(function (d) { return xScale(d.date) })
                .y(function (d) { return yScale(d.total_cases) })
            )

        // [Your Code Here]
        // Define function generating date list and sending it to the method in focus line chart
        function brushed(event) {

        }

    }

    // [Your Code Here]
    // Define method for redrawing context line chart for brushing
    redrawChart(selectedCountry) {

    }

}